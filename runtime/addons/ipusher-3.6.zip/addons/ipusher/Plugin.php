<?php
namespace addons\ipusher;

use taoser\Addons;

/**
 * 插件测试
 * @author byron sampson
 */
class Plugin extends Addons
{
    protected $info = [];

	/**
	 * 初始化
	 *
	 * @return void
	 */
	public function initialize()
	{
		$this->info = $this->getInfo();
	}

    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        return true;
    }

	/**
     * 插件启用方法
     * @return bool
     */
    public function enabled(){
		 return true;
	}
	 
    /**
     * 插件禁用方法
     *
     * @return bool
     */
    public function disabled(){
		return true;
	}

    public function ipusher_index(){
        if($this->info['status'] === 1) {
            return $this->fetch('index');
        }
    }

}