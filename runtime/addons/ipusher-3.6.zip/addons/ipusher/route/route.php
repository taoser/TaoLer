<?php

use think\facade\Route;

//Route::get('ipusher/index','\addons\ipusher\controller\Index@index');
