<?php
/**
* is_nav为插入管理后台菜单子项，即pid。
* 0为顶级菜单目录，1为系统，2为账户，3为插件，4为内容，5为设置，6为服务，7为应用。
* 当is_nav为0时，ismenu必须为0，即菜单目录。
* ismenu 0为目录，1为菜单，2为按钮
*/

return [
    'is_nav' => 0,
    'menu' => [
        //权限地址
        "name"    => "ipusher",
        //权限名称
        "title"   => "ipusher",
        //layui图标
        "icon"    => "layui-icon-survey",
        //是否为菜单
        "ismenu"  => 0,
        //排序
        'sort'   => '21',
        //子菜单
        "sublist" => [
            [
                //权限地址
                "name"    => "addons.ipusher.auth/index",
                //权限名称
                "title"   => "用户授权",
                //layui图标
                "icon"    => "",
                //是否为菜单
                "ismenu"  => 1,
                //排序
                'sort'   => '50',
            ]
        ],
    ]
];
