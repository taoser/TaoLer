DROP INDEX `name` ON tao_addon_ipusher_title;
ALTER TABLE `tao_addon_ipusher_title` ADD INDEX idx_name (`name`);