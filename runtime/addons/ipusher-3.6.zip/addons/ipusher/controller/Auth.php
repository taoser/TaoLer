<?php
namespace addons\ipusher\controller;

use think\facade\Db;
use taoser\addons\Controller;
use think\facade\Request;
use addons\ipusher\model\AddonIpusherAuth;

class Auth extends Controller
{
    /**
     * 用户id
     *
     * @var int
     */
    protected $uid;

    /**
     * @var Model
     */
    protected $model = null;
    /**
     * 不需要登录的方法
     * @var string[]
     */
    protected $noNeedLogin = [];

    /**
     * 不需要鉴权的方法
     * @var string[]
     */
    protected $noNeedAuth = [];

    public function initialize() {
        $this->uid = (int) request()->uid;
        $this->model = new AddonIpusherAuth;
    }

    public function index() {
        $this->assign('addon_ipusher_id', (int) input('id'));
        return $this->fetch('index');
    }

    public function putIn()
    {
        $month = (int) input('month');
        
        //取随机10位字符串
        $strs = "QWERTYUIOPASDFGHJKLZXCVBNM1234567890qwertyuiopasdfghjklzxcvbnm";
        $code = substr(str_shuffle($strs),mt_rand(0,strlen($strs)-11),12);
        
        $res = Db::name('addon_ipusher_auth')->save(
            [
                'user_id' => $this->uid,
                'code'  => $code,
                'active'    => 1,
                'month' => $month,
                'expires_time' => 0,
                'status' => 0,
                'create_time' => date('Y-m-d H:i:s')
                
            ]
        );
        if($res) {
            return json(['code' => 0, 'msg' => '申请成功,等待审核！']);
        }
        return json(['code' => -1, 'msg' => '申请失败！']);
    }

    public function code(){
        $code = input('code');

        $auth = Db::name('addon_ipusher_auth')->field('id,code,month')->where(['user_id' => $this->uid])->find();
        if($code === $auth['code']) {

            $expires = time() + $auth['month'] * 30 * 24 * 60 * 60;

            $res = Db::name('addon_ipusher_auth')->where('id',$auth['id'])->update([
                'active' => 3,
                'expires_time' => $expires
            ]);
            if($res) {
                return json(['code' => 0, 'msg' => '激活成功']);
            }
            return json(['code' => -1, 'msg' => '激活失败']);
        }
        return json(['code' => -1, 'msg' => '激活码无效！']);
    }

    public function checkExpirexTime(){
        $expires = input('expires');
        if($expires > 0) {
            $day = intval(($expires - time()) / (24 * 60 * 60));
            if($day <= 3 && $day > 0) {
                return json(['code' => 0, 'msg' => "{$day}天后到期,请充值"]);
            } elseif($day == 0) {
                return json(['code' => 0, 'msg' => "今天到期,请充值"]);
            } elseif($day < 0) {
                return json(['code' => 0, 'msg' => "已过期,请充值"]);
            }
        }
    }

    // wait
    public function renewal(){
       if(Request::isAjax()){
            $param = Request::only(['month','expires']);
            if($param['expires'] > time()) {
                
            }
       }

       $expires = input('expires');
       $this->assign('expires', $expires);

       return $this->fetch('renewal');
    }


}