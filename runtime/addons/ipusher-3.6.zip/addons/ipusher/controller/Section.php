<?php
namespace addons\ipusher\controller;

use think\facade\Db;
use taoser\addons\Controller;
use think\facade\Request;
use addons\ipusher\model\AddonIpusherSection;

class Section extends Controller
{
    /**
     * 用户id
     *
     * @var int
     */
    protected $uid;

    /**
     * @var Model
     */
    protected $model = null;
    /**
     * 不需要登录的方法
     * @var string[]
     */
    protected $noNeedLogin = [];

    /**
     * 不需要鉴权的方法
     * @var string[]
     */
    protected $noNeedAuth = [];

    public function initialize() {
        $this->uid = (int) request()->uid;
        $this->model = new AddonIpusherSection;
    }

    public function index()
    {
        $this->assign('addon_ipusher_id', (int) input('id'));
        return $this->fetch('index');
    }

    // 添加段意
    public function addName() {
        if(Request::isAjax()) {
            $param = Request::only(['sect_name', 'addon_ipusher_id']);
            $param['create_time'] = date('Y-m-d H:i:s', time());
            $param['user_id'] = $this->uid;
            $res = Db::name('addon_ipusher_section')->save($param);
            if($res) {
                return json(['code' => 0, 'msg' => 'ok']);
            }
            return json(['code' => -1, 'msg' => '添加段意失败']);
        }
    }

    // 段意列表
    public function list() {
        
        if(Request::isAjax()) {
            $section = AddonIpusherSection::with(['section_content'])->where([
                'addon_ipusher_id' => (int) input('addon_ipusher_id'),
                'user_id' => session('user_id')
            ])
            ->paginate([
                'list_rows' => input('limit') ?: 15,
                'page' => input('page') ?: 1
            ])->toArray();

            if($section['total']){
                $data = [];
                foreach($section['data'] as $v) {
                    $data[] = [
                        'id'            => $v['id'],
                        'sect_name'     => $v['sect_name'],
                        'addon_ipusher_id' => $v['addon_ipusher_id'],
                        'content_num'   => count($v['section_content']),
                        'create_time'   => $v['create_time'],
                        'status'        => $v['status']
                    ];
                }
                return json(['code' => 0, 'msg' => 'ok', 'data' => $data, 'count' => $section['total']]);
            }
            return json(['code' => -1, 'msg' => 'no data']);
        }
        
    }

    // 修改段意名
    public function changName() {
        if(Request::isAjax()) {
			$param = Request::param(['id','sect_name']);
			
			$res = Db::name('addon_ipusher_section')->where('id', (int)$param['id'])->update(['sect_name' => $param['sect_name']]);
			if($res > 0) {
				return json(['code' => 0, 'msg' => '成功']);
			}
			return json(['code' => -1, 'msg' => '失败']);
		}
    }

    // 审核段意状态
    public function checkStatus() {
		$param = Request::only(['id','name','value']);
		$data = ['id'=> (int)$param['id'], $param['name']=>(int)$param['value']];

		//获取状态
		$res = Db::name('addon_ipusher_section')->save($data);
	
		if($res){
			return json(['code'=>0,'msg'=>'设置成功','icon'=>6]);
        }
		return json(['code'=>-1,'msg'=>'失败啦','icon'=>6]);
    }

    //删除
	public function delete()
	{
		if(Request::isAjax()){
            $id = input('id');
            $arr = explode(",",$id);
            try {
                foreach($arr as $v){
                    $title = $this->model->with('sectionContent')->where(['user_id' => $this->uid])->find($v);
                    $title->together(['sectionContent'])->delete();
                }
                return json(['code'=>0,'msg'=>'删除成功']);
            } catch (\Exception $e) {
                return json(['code'=>-1,'msg'=>$e->getMessage()]);
            }
		}
	}

}