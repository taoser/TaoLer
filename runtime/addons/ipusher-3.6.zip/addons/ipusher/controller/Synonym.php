<?php
namespace addons\ipusher\controller;

use think\facade\Db;
use taoser\addons\Controller;
use think\facade\Request;

use addons\ipusher\model\AddonIpusher;
use addons\ipusher\model\AddonSection;
use addons\ipusher\model\AddonSectionContent;

class Synonym extends Controller
{
    /**
     * 用户id
     *
     * @var int
     */
    protected $uid;

    /**
     * @var Model
     */
    protected $model = null;
    /**
     * 不需要登录的方法
     * @var string[]
     */
    protected $noNeedLogin = [];

    /**
     * 不需要鉴权的方法
     * @var string[]
     */
    protected $noNeedAuth = [];

    public function initialize() {
        $this->uid = request()->uid;
    }

    public function index()
    {
        $words = Db::name('addon_synonym')->where('user_id', $this->uid)->value('words') ?? '';

        $this->assign('words', $words);
        return $this->fetch('index');
    }

    public function add() {
        if(Request::isAjax()) {
            $words = input('words');
            try{
                $hasWords = Db::name('addon_synonym')->where('user_id', $this->uid)->find();
                if(is_null($hasWords)) {
                    Db::name('addon_synonym')->save(['user_id' => $this->uid, 'words' => $words]);
                } else {
                    Db::name('addon_synonym')->where('user_id', $this->uid)->update(['words' => $words]);
                }
            } catch(\Exception $e){
                return json(['code' => -1, 'msg' => $e->getMessage()]);
            }
            return json(['code' => 0, 'msg' => 'ok']);            
        }
    }

    public function getKeyValArr(){
        $words = Db::name('addon_synonym')->where('user_id', $this->uid)->value('words');
        
        $data = [];
        if(!empty($words)) {
            $arr = explode("\n",$words);
            foreach($arr as $v) {
                $wArr = explode("|",$v);
                $data[$wArr[0]] = $wArr[1];
            }
        }
        
        return $data;
    }
}