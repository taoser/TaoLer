<?php
namespace addons\ipusher\controller;

use think\facade\Db;
use taoser\addons\Controller;
use think\facade\Request;
use addons\ipusher\model\AddonIpusherArticle;

class Article extends Controller
{
    protected $uid;
    protected $model = null;
    protected $noNeedLogin = [];
    protected $noNeedAuth = [];

    public function initialize() {
        $this->uid = (int) request()->uid;
        $this->model = new AddonIpusherArticle;
    }

    public function index() {
        $this->assign('addon_ipusher_id', (int) input('id'));
        return $this->fetch('index');
    }

    // 标题列表
    public function list() {
        
        if(Request::isAjax()) {
            $timer = input('timer');
            $where = [];
            if($timer == '1') {
                $where = ['push_time' => 0];
            }
            if($timer == '2') {
                $where = [['push_time', '>', 0]];
            }

            $list = $this->model->with(['ipusher'])
            ->where([
                'addon_ipusher_id' => (int) input('addon_ipusher_id'),
                'user_id' => $this->uid
            ])
            ->where($where)
            ->order('id', 'desc')
            ->paginate([
                'list_rows' => input('limit') ?: 100,
                'page' => input('page') ?: 1
            ])->toArray();

            if($list['total']){
                $data = [];
                foreach($list['data'] as $v) {
                    $data[] = [
                        'id'       => $v['id'],
                        'title'     => $v['title'],
                        'create_time'   => $v['create_time'],
                        'push_time' => $v['push_time'] == 0 ? '无' : date('Y-m-d H:i:s', $v['push_time'])
                    ];
                }
                return json(['code' => 0, 'msg' => 'ok', 'data' => $data, 'count' => $list['total']]);
            }
            return json(['code' => -1, 'msg' => 'no data']);
        }
        
    }



    // 修改标题
    public function changName() {
        if(Request::isAjax()) {
			$param = Request::param(['id','title']);
			
			$res = Db::name('addon_ipusher_article')->where([
                'id' => (int)$param['id'],
                'user_id' => $this->uid
            ])->update(['title' => $param['title']]);
			if($res > 0) {
				return json(['code' => 0, 'msg' => '成功']);
			}
			return json(['code' => -1, 'msg' => '失败']);
		}
    }

     // 发布
	public function post()
	{
		if(Request::isAjax()){
            $id = input('id');
            $arr = explode(",",$id);
            $data = [];
            $idArr = [];
            $time = time();

            try {
                $article = $this->model->where('user_id', $this->uid)->where('id','in',$arr)->select();
                foreach($article as $v) {
                    if($v['push_time'] !== 0) return json(['code'=>-1,'msg'=> '已定时不能手动发布！']);
                    array_push($idArr, $v['id']);
                    $data[] = [
                        'title'     => $v['title'],
                        'content'   => $v['content'],
                        'user_id'   => $v['user_id'],
                        'cate_id'   => $v['cate_id'],
                        'keywords'  => $v['keywords'],
                        'description'   => getArtContent($v['content']),
                        'create_time'   => $time,
                        'update_time'   => $time
                    ];
                }

                Db::name('article')->insertAll($data);

                Db::name('addon_ipusher_article')->delete($idArr);

                return json(['code'=>0,'msg'=>'发布成功']);
            } catch (\Exception $e) {
                return json(['code'=>-1,'msg'=> $e->getMessage()]);
            }
		}
	}
        
    //删除
	public function delete()
	{
		if(Request::isAjax()){
            $id = input('id');
            $arr = explode(",",$id);
            try {
                foreach($arr as $v){
                    $title = $this->model->where(['user_id' => $this->uid])->find($v);
                    $title->delete();
                }
                return json(['code'=>0,'msg'=>'删除成功']);
            } catch (\Exception $e) {
                return json(['code'=>-1,'msg'=>'删除失败']);
            }
		}
	}

    public function allDelete()
	{
        try {
            Db::name('addon_ipusher_article')->where(['user_id' => $this->uid, 'addon_ipusher_id' => (int) input('addon_ipusher_id')])->delete(true);
            return json(['code'=>0,'msg'=>'删除成功']);
        } catch (\Exception $e) {
            return json(['code'=>-1,'msg'=>'删除失败']);
        }
	}

}