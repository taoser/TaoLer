<?php
namespace addons\ipusher\controller;

use think\facade\Db;
use taoser\addons\Controller;
use think\facade\Request;

use addons\ipusher\model\AddonIpusher;
use addons\ipusher\model\AddonIpusherTitle;

class Title extends Controller
{
    protected $uid;
    protected $noNeedLogin = [];
    protected $noNeedAuth = [];

    public function initialize() {
        $this->uid = (int) request()->uid;
    }

    public function index() {
        $this->assign('addon_ipusher_id', (int) input('id'));
        return $this->fetch('index');
    }

    // 标题列表
    public function list() {
        
        if(Request::isAjax()) {
            $list = AddonIpusherTitle::with(['ipusher'])
            ->where([
                'addon_ipusher_id' => (int) input('addon_ipusher_id'),
                'user_id' => $this->uid
            ])
            ->order('id', 'desc')
            ->paginate([
                'list_rows' => input('limit') ?: 100,
                'page' => input('page') ?: 1
            ])
            ->toArray();

            if($list['total']){
                $data = [];
                foreach($list['data'] as $v) {
                    $data[] = [
                        'id'       => $v['id'],
                        'name'     => $v['name'],
                        'create_time'   => $v['create_time']
                    ];
                }
                return json(['code' => 0, 'msg' => 'ok', 'data' => $data, 'count' => $list['total']]);
            }
            return json(['code' => -1, 'msg' => 'no data']);
        }
        
    }

    // 添加标题
    public function add() {
        if(Request::isAjax()) {
            $param = Request::only(['addon_ipusher_id','head','main','foot','end','group','area']);
            $ipusherId = (int) $param['addon_ipusher_id'];
            $titleArr = Db::name('addon_ipusher_title')->where('addon_ipusher_id', $param['addon_ipusher_id'])->column('name');

            $arrA = [];
            if(!empty($param['area'])) {
                foreach($param['area'] as $v) {
                    array_push($arrA, $v['title']);
                }
            }
            
            $arrB = explode("\n",$param['head']);
            $arrC = explode("\n",$param['main']);
            $arrD = explode("\n",$param['foot']);
            $arrE = explode("\n",$param['end']);

            $data = [];
            switch($param['group']) {
                case 'ABCD':
                    if(count($arrA) === 0) return json(['code' => -1, 'msg' => 'A不能为空']);
                    if(count($arrB) === 0) return json(['code' => -1, 'msg' => 'B不能为空']);
                    if(count($arrC) === 0) return json(['code' => -1, 'msg' => 'C不能为空']);
                    if(count($arrD) === 0) return json(['code' => -1, 'msg' => 'D不能为空']);
                    foreach ($arrA as $a) {
                        foreach ( $arrB as $b) {
                            foreach ($arrC as $c) {
                                foreach ($arrD as $d) {
                                    $name = $a.$b.$c.$d;
                                    if(in_array($name, $titleArr)) continue;
                                    $data[] = ['name' => $name, 'addon_ipusher_id' => $ipusherId, 'user_id' => $this->uid, 'main' => $c, 'city' => $a];
                                }
                            }
                        }
                    }
                    break;
                case 'ABC':
                    if(count($arrA) === 0) return json(['code' => -1, 'msg' => 'A不能为空']);
                    if(count($arrB) === 0) return json(['code' => -1, 'msg' => 'B不能为空']);
                    if(count($arrC) === 0) return json(['code' => -1, 'msg' => 'C不能为空']);
                    foreach ($arrA as $a) {
                        foreach ( $arrB as $b) {
                            foreach ($arrC as $c) {
                                $name = $a.$b.$c;
                                if(in_array($name, $titleArr)) continue;
                                $data[] = ['name' => $name, 'addon_ipusher_id' => $ipusherId, 'user_id' => $this->uid, 'main' => $c, 'city' => $a];
                            }
                        }
                    }
                    break;
                case 'ACD':
                    if(count($arrA) === 0) return json(['code' => -1, 'msg' => 'A不能为空']);
                    if(count($arrC) === 0) return json(['code' => -1, 'msg' => 'C不能为空']);
                    if(count($arrD) === 0) return json(['code' => -1, 'msg' => 'D不能为空']);
                    foreach ($arrA as $a) {
                        foreach ( $arrC as $c) {
                            foreach ($arrD as $d) {
                                $name = $a.$c.$d;
                                if(in_array($name, $titleArr)) continue;
                                $data[] = ['name' => $name, 'addon_ipusher_id' => $ipusherId, 'user_id' => $this->uid, 'main' => $c, 'city' => $a];
                            }
                        }
                    }
                    break;
                case 'BCD':
                    if(count($arrB) === 0) return json(['code' => -1, 'msg' => 'B不能为空']);
                    if(count($arrC) === 0) return json(['code' => -1, 'msg' => 'C不能为空']);
                    if(count($arrD) === 0) return json(['code' => -1, 'msg' => 'D不能为空']);
                    foreach ($arrB as $b) {
                        foreach ( $arrC as $c) {
                            foreach ($arrD as $d) {
                                $name = $b.$c.$d;
                                if(in_array($name, $titleArr)) continue;
                                $data[] = ['name' => $name, 'addon_ipusher_id' => $ipusherId, 'user_id' => $this->uid, 'main' => $c];
                            }
                        }
                    }
                    break;
                case 'AC':
                    if(count($arrA) === 0) return json(['code' => -1, 'msg' => 'A不能为空']);
                    if(count($arrC) === 0) return json(['code' => -1, 'msg' => 'C不能为空']);
                    foreach ($arrA as $a) {
                        foreach ($arrC as $c) {
                            $name = $a.$c;
                            if(in_array($name, $titleArr)) continue;
                            $data[] = ['name' => $name, 'addon_ipusher_id' => $ipusherId, 'user_id' => $this->uid, 'main' => $c, 'city' => $a];
                        } 
                    }
                    break;
                case 'BC':
                    if(count($arrB) === 0) return json(['code' => -1, 'msg' => 'B不能为空']);
                    if(count($arrC) === 0) return json(['code' => -1, 'msg' => 'C不能为空']);
                    foreach ($arrB as $b) {
                        foreach ($arrC as $c) {
                            $name = $b.$c;
                            if(in_array($name, $titleArr)) continue;
                            $data[] = ['name' => $name, 'addon_ipusher_id' => $ipusherId, 'user_id' => $this->uid, 'main' => $c];
                        } 
                    }
                    break;
                case 'CD':
                    if(count($arrC) === 0) return json(['code' => -1, 'msg' => 'C不能为空']);
                    if(count($arrD) === 0) return json(['code' => -1, 'msg' => 'D不能为空']);
                    foreach ($arrC as $c) {
                        foreach ($arrD as $d) {
                            $name = $c.$d;
                            if(in_array($name, $titleArr,true)) continue;
                            $data[] = ['name' => $name, 'addon_ipusher_id' => $ipusherId, 'user_id' => $this->uid, 'main' => $c];
                        } 
                    }
                    break; 
                case 'C':
                    if(count($arrC) === 0) return json(['code' => -1, 'msg' => 'C不能为空']);
                    foreach ($arrC as $c) {
                        $name = $c;
                        if(in_array($name, $titleArr)) continue;
                        $data[] = ['name' => $name, 'addon_ipusher_id' => $ipusherId, 'user_id' => $this->uid, 'main' => $c];
                    }
                    break; 
                case 'CDE':
                    if(count($arrC) === 0) return json(['code' => -1, 'msg' => 'C不能为空']);
                    if(count($arrD) === 0) return json(['code' => -1, 'msg' => 'D不能为空']);
                    if(count($arrE) === 0) return json(['code' => -1, 'msg' => 'E不能为空']);
                    foreach ($arrC as $c) {
                        foreach ( $arrD as $d) {
                            foreach ($arrE as $e) {
                                $name = $c.$d.$e;
                                if(in_array($name, $titleArr)) continue;
                                $data[] = ['name' => $name, 'addon_ipusher_id' => $ipusherId, 'user_id' => $this->uid, 'main' => $c];
                            }
                        }
                    }
                    break;  
            }

            if(count($data) == 0) return json(['code'=> -1, 'msg'=>'当前标题重复，无需再生成！！']);
            
            shuffle($data);
            
            try {
                $addonIpusherTitle = new AddonIpusherTitle();
                $addonIpusherTitle->saveAll($data);
            } catch (\Exception $e) {
                return json(['code'=>-1,'msg'=>$e->getMessage()]);
            }
            return json(['code'=>0,'msg'=>'添加成功']);
        }

    }

    // 修改标题
    public function changName() {
        if(Request::isAjax()) {
			$param = Request::param(['id','name']);
			
			$res = Db::name('addon_ipusher_title')->where([
                'id' => (int)$param['id'],
                'user_id' => $this->uid
            ])->update(['name' => $param['name']]);
			if($res > 0) {
				return json(['code' => 0, 'msg' => '成功']);
			}
			return json(['code' => -1, 'msg' => '失败']);
		}
    }
        
    //删除
	public function delete()
	{
		if(Request::isAjax()){
            $id = input('id');
            $arr = explode(",",$id);
            try {
                foreach($arr as $v){
                    $title = AddonIpusherTitle::where(['user_id' => $this->uid])->find($v);
                    $title->delete();
                }
                return json(['code'=>0,'msg'=>'删除成功']);
            } catch (\Exception $e) {
                return json(['code'=>-1,'msg'=>'删除失败']);
            }
		}
	}

	public function allDelete()
	{
        try {
            Db::name('addon_ipusher_title')->where(['user_id' => $this->uid, 'addon_ipusher_id' => (int) input('addon_ipusher_id')])->delete(true);
            return json(['code'=>0,'msg'=>'删除成功']);
        } catch (\Exception $e) {
            return json(['code'=>-1,'msg'=>'删除失败']);
        }
	}


}