<?php
namespace addons\ipusher\controller;

use think\facade\Db;
use taoser\addons\Controller;
use think\facade\Request;
use think\facade\View;

use addons\ipusher\model\AddonIpusher;
use addons\ipusher\model\AddonSection;
use addons\ipusher\model\AddonSectionContent;

class Index extends Controller
{
    protected $uid;
    /**
     * @var Model
     */
    protected $model = null;
    /**
     * 不需要登录的方法
     * @var string[]
     */
    protected $noNeedLogin = [];

    /**
     * 不需要鉴权的方法
     * @var string[]
     */
    protected $noNeedAuth = [];

    // 控制器中间件
    protected $middleware = [ 
    	'logincheck' => ['ext' => 1]
    ];

    public function initialize()
    {
        $this->uid = request()->uid;
        $this->model = new AddonIpusher;
    }

    public function index()
    {
        $uAuth = Db::name('addon_ipusher_auth')->field('active,expires_time')->where('user_id', $this->uid)->find();
        if(is_null($uAuth)){
            $active = 0;
            $expires = 0;
        } else {
            if($uAuth['active'] == 3){
                $active = 3;
            } elseif($uAuth['active'] == 2) {
                $active = 2;
            } elseif($uAuth['active'] == 1) {
                    $active = 1;
            } else {
                $active = 0;
            }
            $expires = $uAuth['expires_time'];
        }

        $this->assign('active', $active);
        $this->assign('expires', $expires);
        return $this->fetch('index');
    }

    // 主题列表
    public function list(){
        $list = AddonIpusher::field('id,name,cate_id')->with(
            ['cate'=>function($query){
                $query->withField(['id,catename']);
            }]
        )
        ->withCount(['section','title','tpl','article'])
        ->where(['user_id' => request()->uid])
        ->paginate([
            'list_rows' => input('limit') ?: 15,
            'page' => input('page') ?: 1
        ])
        ->order('id desc')
        ->toArray();

        if($list['total']) {
            $data = [];
            $cate = [];
            $cates = Db::name('cate')->where(['delete_time' => 0, 'status' => 1])->column('id,catename');
            foreach($cates as $v) {
                $cate[] = ['id' => $v['id'], 'title' => $v['catename']]; 
            }
            foreach($list['data'] as $v) {
                $data[] = [
                    'id'        => $v['id'],
                    'name'      => $v['name'],
                    'catename'  => $v['cate']['catename'],
                    'section_num'   => $v['section_count'],
                    'title_num'     => $v['title_count'],
                    'article_num'   => $v['article_count'],
                    'tpl_num'       => $v['tpl_count']
                ];
            }
            return json(['code' => 0, 'msg' => 'ok', 'data' => $data, 'count' => $list['total'], 'cate' => $cate]);
        }
        return json(['code' => -1, 'msg' => 'no data']);
    }

    // 添加主题
    public function add(){
        if(Request::isAjax()) {
            $param = Request::param(['name','cate_id']);
            $param['cate_id'] = (int) $param['cate_id'];
            $param['create_time'] = time();
            $param['user_id'] = session('user_id');

            try{
                Db::name('addon_ipusher')->save($param);
                return json(['code' => 0, 'msg' => 'ok']);
            } catch(\Exception $e) {
                return json(['code' => -1, 'msg' => $e->getMessage()]);
            }
        }
        return $this->fetch('add');
    }

    // 设置主题页
    public function set() {
        $id = (int)input('id');
        $ipusher = AddonIpusher::with(['section'])->find($id);
        
        $this->assign('ipusher', $ipusher);
        
        return $this->fetch('set');
    }

    // 设置主题名
    public function setName()
    {
        if(Request::isAjax()) {
			$param = Request::param(['id','name']);
			
			$res = Db::name('addon_ipusher')->where('id', (int)$param['id'])->update(['name' => $param['name']]);
			if($res > 0) {
				return json(['code' => 0, 'msg' => '成功']);
			}
			return json(['code' => -1, 'msg' => '失败']);
		}
    }

    // 编辑分类
	public function changeCate()
	{
		if(Request::isAjax()) {
			$param = Request::param(['id','cate_id']);

			$res = Db::name('addon_ipusher')->where('id',(int)$param['id'])->update(['cate_id' => (int)$param['cate_id']]);
			if($res > 0) {
				return json(['code' => 0, 'msg' => '修改成功']);
			}
			return json(['code' => -1, 'msg' => '修改失败']);
		}
	}

    
    //删除
    public function delete()
    {
        if(Request::isAjax()){
            $id = input('id');
            $arr = explode(",",$id);
            try {
                foreach($arr as $v){
                    $title = AddonIpusher::where(['user_id' => session('user_id')])->find($v);
                    $title->delete();
                }
                return json(['code'=>0,'msg'=>'删除成功']);
            } catch (\Exception $e) {
                return json(['code'=>-1,'msg'=>'删除失败']);
            }
        }
    }
    
    /**
     * 分类
     * @return \think\response\Json
     */
    public function getCateList()
    {
        $cateList = Db::name('cate')->field('id,pid,catename,sort')->where(['status' => 1])->select()->toArray();
        // 排序
        $cmf_arr = array_column($cateList, 'sort');
        array_multisort($cmf_arr, SORT_ASC, $cateList);

        $list =  getTree($cateList);
        $count = count($list);
        $tree = [];
        if($count){
            $tree = ['code'=>0, 'msg'=>'ok','count'=>$count];
            $tree['data'] = $list;
        }

        return json($tree);
    }

}