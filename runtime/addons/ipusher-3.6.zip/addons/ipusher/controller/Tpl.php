<?php
namespace addons\ipusher\controller;

use think\facade\Db;
use taoser\addons\Controller;
use think\facade\Request;
use addons\ipusher\model\AddonIpusherTpl;
use think\App;

class Tpl extends Controller
{
    /**
     * 用户id
     *
     * @var int
     */
    protected $uid;

    /**
     * @var Model
     */
    protected $model = null;
    /**
     * 不需要登录的方法
     * @var string[]
     */
    protected $noNeedLogin = [];

    /**
     * 不需要鉴权的方法
     * @var string[]
     */
    protected $noNeedAuth = [];

    public function initialize() {
        $this->uid = (int) request()->uid;
        $this->model = new AddonIpusherTpl;
    }

    public function index() {
        $this->assign('addon_ipusher_id', (int) input('id'));
        return $this->fetch('index');
    }

    // 内容列表
    public function list() {
        
        if(Request::isAjax()) {
            $list = AddonIpusherTpl::with(['ipusher'])->where('addon_ipusher_id', (int) input('addon_ipusher_id'))
            ->paginate([
                'list_rows' => input('limit') ?: 15,
                'page' => input('page') ?: 1
            ])->toArray();

            if($list['total']){
                $data = [];
                foreach($list['data'] as $v) {
                    $data[] = [
                        'id'        => $v['id'],
                        'name'      => $v['name'],
                        'layout'    => strip_tags($v['layout']),
                        'addon_ipusher_id' => $v['addon_ipusher_id'],
                        'create_time'   => $v['create_time']
                    ];
                }
                return json(['code' => 0, 'msg' => 'ok', 'data' => $data, 'count' => $list['total']]);
            }
            return json(['code' => -1, 'msg' => 'no data']);
        }
        
    }

    // 添加tpl内容
    public function add() {
        if(Request::isAjax()) {
            $param['addon_ipusher_id'] = Request::post('addon_ipusher_id/d');
            $param['layout'] = Request::post('layout');
            $param['user_id'] = (int) session('user_id');
            $param['name'] = Request::post('name');

            if(empty($param['layout'])) {
                return json(['code'=>-1,'msg'=>'内容不能为空']);
            }

            $hasTpl = AddonIpusherTpl::where(['user_id' => $param['user_id'], 'addon_ipusher_id' => $param['addon_ipusher_id'], 'name' => $param['name']])->find();
            if(!is_null($hasTpl)) {
                return json(['code'=>-1,'msg'=>'名称已存在']);
            }

            try {
                AddonIpusherTpl::create($param);
            } catch (\Exception $e) {
                return json(['code'=>-1,'msg'=>'失败啦']);
            }
            return json(['code'=>0,'msg'=>'添加成功']);
        }

        $ipusher_id = input('iid');
        $section_id = input('sid');
        $this->assign(['ipusher_id' => $ipusher_id, 'section_id' => $section_id]);
        return $this->fetch('add');  
    }

    // 编辑模板内容
    public function edit() {
        if(Request::isAjax()) {
			$param['id'] = Request::post('id/d');
            $param['seo'] = Request::post('seo');
            $param['layout'] = Request::post('layout');
            if(empty($param['layout'])) {
                return json(['code'=>-1,'msg'=>'内容不能为空']);
            }

            try {
                AddonIpusherTpl::update($param);
            } catch (\Exception $e) {
                return json(['code'=>-1,'msg'=>'失败啦']);
            }
            return json(['code'=>0,'msg'=>'成功']);
        }

        $id = (int) input('id');
        $tpl = Db::name('addon_ipusher_tpl')->find($id);

        $section = Db::name('addon_ipusher_section')->where(['addon_ipusher_id' => $tpl['addon_ipusher_id'], 'user_id' => $this->uid])->select();
        $this->assign(['tpl' => $tpl, 'section' => $section]);
        return $this->fetch('edit');  
    }

    // 修改名称
    public function changName() {
        if(Request::isAjax()) {
			$param = Request::param(['id','name','addon_ipusher_id']);
            $uid = (int) request()->uid;

            $hasTpl = AddonIpusherTpl::where(['user_id' => $uid, 'addon_ipusher_id' => $param['addon_ipusher_id'], 'name' => $param['name']])->find();
            if(!is_null($hasTpl)) {
                return json(['code'=>-1,'msg'=>'名称已存在']);
            }
			
			$res = Db::name('addon_ipusher_tpl')->where([
                'id' => (int)$param['id'],
                'user_id' => session('user_id')
            ])->update(['name' => $param['name']]);
			if($res > 0) {
				return json(['code' => 0, 'msg' => '成功']);
			}
			return json(['code' => -1, 'msg' => '失败']);
		}
    }

    //删除
	public function delete()
	{
		if(Request::isAjax()){
            $id = input('id');
            $arr = explode(",",$id);
            try {
                foreach($arr as $v){
                    $title = AddonIpusherTpl::where(['user_id' => session('user_id')])->find($v);
                    $title->delete();
                }
                return json(['code'=>0,'msg'=>'删除成功']);
            } catch (\Exception $e) {
                return json(['code'=>-1,'msg'=>'删除失败']);
            }
		}
	}


}