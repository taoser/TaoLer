<?php
namespace addons\ipusher\controller;

use think\facade\Db;
use taoser\addons\Controller;
use think\facade\Request;
use addons\ipusher\model\AddonIpusherSectionContent;
use addons\ipusher\controller\Synonym;

class Content extends Controller
{
    /**
     * 用户id
     *
     * @var int
     */
    protected $uid;

    /**
     * @var Model
     */
    protected $model = null;
    /**
     * 不需要登录的方法
     * @var string[]
     */
    protected $noNeedLogin = [];

    /**
     * 不需要鉴权的方法
     * @var string[]
     */
    protected $noNeedAuth = [];

    public function initialize() {
        $this->uid = (int) request()->uid;
        $this->model = new AddonIpusherSectionContent;
    }

    public function index() {
        $this->assign('addon_section_id', (int) input('id'));
        return $this->fetch('index');
    }

    // 内容列表
    public function list() {
        
        if(Request::isAjax()) {
            $list = AddonIpusherSectionContent::with(['section'])
            ->where('addon_ipusher_section_id', (int) input('addon_section_id'))
            ->order('id','desc')
            ->paginate([
                'list_rows' => input('limit') ?: 100,
                'page' => input('page') ?: 1
            ])
            ->toArray();

            if($list['total']){
                $data = [];
                foreach($list['data'] as $v) {
                    $data[] = [
                        'id'            => $v['id'],
                        'sect_name'     => $v['section']['sect_name'],
                        'section_content'   => strip_tags($v['section_content']),
                        'status' => $v['status'],
                        'create_time'   => $v['create_time']
                    ];
                }
                return json(['code' => 0, 'msg' => 'ok', 'data' => $data, 'count' => $list['total']]);
            }
            return json(['code' => -1, 'msg' => 'no data']);
        }
        
    }

    // 审核内容状态
    public function checkStatus() {
		$param = Request::only(['id','name','value']);
        // halt($param);
		$data = ['id'=> (int)$param['id'], $param['name']=>(int)$param['value']];
        // halt($data);
		//获取状态
		$res = Db::name('addon_ipusher_section_content')->save($data);
	
		if($res){
			return json(['code'=>0,'msg'=>'设置成功','icon'=>6]);
        }
		return json(['code'=>-1,'msg'=>'失败啦','icon'=>6]);
    }

    // 添加段意内容
    public function add() {
        if(Request::isAjax()) {
			$param['addon_ipusher_section_id'] = Request::post('addon_section_id/d');
            $param['addon_ipusher_id'] = Request::post('addon_ipusher_id/d');
            $param['section_content'] = Request::post('section_content');
            $turn = Request::post('synonym');
            if(empty($param['section_content'])) {
                return json(['code'=>-1,'msg'=>'内容不能为空']);
            }
            if($turn == 'on') {
                $synonym = new Synonym(app());
                $vkArr = $synonym->getKeyValArr();
                foreach($vkArr as $k => $v) {
                    $param['section_content'] = str_replace($k,$v,$param['section_content']);
                }
            }

            $data = [];
            $arr = explode("<p>!@#*!</p>",$param['section_content']);
            foreach($arr as $v) {
                $data[] = [
                    'addon_ipusher_section_id' => $param['addon_ipusher_section_id'],
                    'addon_ipusher_id' => $param['addon_ipusher_id'],
                    'section_content'  => str_replace("\n",'',$v),
                    'user_id' => $this->uid
                ];
            }

            try {
                //AddonSectionContent::create($param);
                $content = new AddonIpusherSectionContent();
                $content->saveAll($data);
            } catch (\Exception $e) {
                return json(['code'=>-1,'msg'=>'失败啦']);
            }
            return json(['code'=>0,'msg'=>'添加成功']);
        }

        $ipusher_id = input('iid');
        $section_id = input('sid');
        $this->assign(['ipusher_id' => $ipusher_id, 'section_id' => $section_id]);
        return $this->fetch('add');  
    }

    // 编辑段意内容
    public function edit() {
        if(Request::isAjax()) {
			$param['id'] = Request::post('id/d');
            $param['section_content'] = Request::post('section_content');
            $param['user_id'] = $this->uid;
            $turn = Request::post('synonym');
            if(empty($param['section_content'])) {
                return json(['code'=>-1,'msg'=>'内容不能为空']);
            }
            if($turn == 'on') {
                $synonym = new Synonym(app());
                $vkArr = $synonym->getKeyValArr();
                foreach($vkArr as $k => $v) {
                    $param['section_content'] = str_replace($k,$v,$param['section_content']);
                }
            }

            try {
                AddonIpusherSectionContent::update($param);
            } catch (\Exception $e) {
                return json(['code'=>-1,'msg'=>'失败啦']);
            }
            return json(['code'=>0,'msg'=>'成功']);
        }

        $id = (int) input('id');
        $content = Db::name('addon_ipusher_section_content')->find($id);

        $this->assign(['content' => $content]);
        return $this->fetch('edit');  
    }

     //删除
	public function delete()
	{
		if(Request::isAjax()){
            $id = input('id');
            $arr = explode(",",$id);
            try {
                foreach($arr as $v){
                    $title = $this->model->where(['user_id' => $this->uid])->find($v);
                    $title->delete();
                }
                return json(['code'=>0,'msg'=>'删除成功']);
            } catch (\Exception $e) {
                return json(['code'=>-1,'msg'=>'删除失败']);
            }
		}
	}

    public function allDelete()
	{
        try {
            Db::name('addon_ipusher_section_content')->where(['user_id' => $this->uid, 'addon_ipusher_section_id' => (int)input('addon_section_id')])->delete(true);
            return json(['code'=>0,'msg'=>'删除成功']);
        } catch (\Exception $e) {
            return json(['code'=>-1,'msg'=>'删除失败']);
        }
	}

}