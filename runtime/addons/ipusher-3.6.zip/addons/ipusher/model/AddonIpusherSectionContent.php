<?php
namespace addons\ipusher\model;

use think\Model;

class AddonIpusherSectionContent extends Model
{
    // 段意关联产品
    public function section()
    {
        return $this->belongsTo(AddonIpusherSection::class);
    }
}