<?php
namespace addons\ipusher\model;

use think\Model;
use app\common\model\Cate;
class AddonIpusherTitle extends Model
{
    //关联段意
	public function ipusher()
	{
		return $this->belongsTo(AddonIpusher::class);
	}
}