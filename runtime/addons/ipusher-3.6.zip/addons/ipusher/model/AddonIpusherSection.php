<?php
namespace addons\ipusher\model;

use think\Model;

class AddonIpusherSection extends Model
{
    // 段意关联产品
    public function ipusher()
    {
        return $this->belongsTo(AddonIpusher::class);
    }

    //关联段意
	public function sectionContent()
	{
		return $this->hasMany(AddonIpusherSectionContent::class);
	}
}