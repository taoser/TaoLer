<?php
namespace addons\ipusher\model;

use think\Model;
use app\common\model\Cate;
class AddonIpusher extends Model
{
    //关联段意
	public function section()
	{
		return $this->hasMany(AddonIpusherSection::class);
	}

	//关联段意
	public function cate()
	{
		return $this->belongsTo(Cate::class);
	}

	//关联标题
	public function title()
	{
		return $this->hasMany(AddonIpusherTitle::class);
	}

	//关联模板
	public function tpl()
	{
		return $this->hasMany(AddonIpusherTpl::class);
	}

	//关联文章
	public function article()
	{
		return $this->hasMany(AddonIpusherArticle::class);
	}
}