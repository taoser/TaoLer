<?php
namespace addons\ipusher\model;

use think\Model;
use app\common\model\User;

class AddonIpusherAuth extends Model
{
    //关联段意
	public function user()
	{
		return $this->belongsTo(User::class);
	}
}