DROP TABLE IF EXISTS `tao_addon_ipusher`;
CREATE TABLE `tao_addon_ipusher`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '产品id',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '产品名',
  `user_id` int NOT NULL COMMENT '用户ID',
  `cate_id` int NOT NULL COMMENT '分类id',
  `main_word` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '主词',
  `create_time` int NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_uid_cid`(`user_id` ASC, `cate_id` ASC) USING BTREE COMMENT '用户类型索引'
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

DROP TABLE IF EXISTS `tao_addon_ipusher_article`;
CREATE TABLE `tao_addon_ipusher_article`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `addon_ipusher_id` int NOT NULL COMMENT '主题ID',
  `user_id` int NOT NULL COMMENT '用户ID',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '标题',
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '内容',
  `cate_id` int NOT NULL COMMENT '分类',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键词',
  `create_time` datetime NOT NULL COMMENT '时间',
  `push_time` int NOT NULL DEFAULT 0 COMMENT '推送时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

DROP TABLE IF EXISTS `tao_addon_ipusher_auth`;
CREATE TABLE `tao_addon_ipusher_auth`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `create_time` datetime NOT NULL,
  `month` tinyint NOT NULL,
  `expires_time` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

DROP TABLE IF EXISTS `tao_addon_ipusher_order`;
CREATE TABLE `tao_addon_ipusher_order`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `month` tinyint NOT NULL,
  `create_time` datetime NOT NULL,
  `is_buy` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

DROP TABLE IF EXISTS `tao_addon_ipusher_section`;
CREATE TABLE `tao_addon_ipusher_section`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '段意ID',
  `sect_name` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '段意名称',
  `addon_ipusher_id` int NOT NULL COMMENT '产品id',
  `user_id` int NOT NULL COMMENT '用户ID',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_ipusher_id`(`addon_ipusher_id` ASC) USING BTREE COMMENT 'ipusherID'
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

DROP TABLE IF EXISTS `tao_addon_ipusher_section_content`;
CREATE TABLE `tao_addon_ipusher_section_content`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '段意内容ID',
  `addon_ipusher_section_id` int NOT NULL COMMENT '段意ID',
  `addon_ipusher_id` int NOT NULL COMMENT '主题ID',
  `user_id` int NOT NULL COMMENT '用户ID',
  `section_content` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '段意内容',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_sectiobid_ipusherid`(`addon_ipusher_section_id` ASC, `addon_ipusher_id` ASC) USING BTREE COMMENT '段落主题索引'
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

DROP TABLE IF EXISTS `tao_addon_ipusher_title`;
CREATE TABLE `tao_addon_ipusher_title`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '标题ID',
  `addon_ipusher_id` int NOT NULL COMMENT '主题ID',
  `user_id` int NOT NULL COMMENT '用户ID',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '名称',
  `main` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '主词',
  `city` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '城市',
  `create_time` datetime NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

DROP TABLE IF EXISTS `tao_addon_ipusher_tpl`;
CREATE TABLE `tao_addon_ipusher_tpl`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '模板ID',
  `addon_ipusher_id` int NOT NULL COMMENT '主题ID',
  `user_id` int NOT NULL COMMENT '用户ID',
  `name` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '模板名称',
  `layout` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '模板内容',
  `seo` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'seo内容',
  `create_time` datetime NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

DROP TABLE IF EXISTS `tao_addon_synonym`;
CREATE TABLE `tao_addon_synonym`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `user_id` int NOT NULL COMMENT '用户id',
  `words` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '同义词文本',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `idx_uid`(`user_id` ASC) USING BTREE COMMENT '用户ID'
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;